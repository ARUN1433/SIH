import express, { Request, Response, NextFunction } from "express";
import { createServer as createViteServer } from "vite";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import { getSmartSuggestion } from "./src/services/geminiService.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("helpdesk.db");
const JWT_SECRET = "placement-ready-secret-key";

// Extend Request type for JWT user
interface AuthRequest extends Request {
  user?: { id: number; role: string; name: string };
}

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT CHECK(role IN ('USER', 'TECHNICIAN', 'ADMIN')) DEFAULT 'USER'
  );

  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    priority TEXT CHECK(priority IN ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW')),
    category TEXT CHECK(category IN ('HARDWARE', 'SOFTWARE', 'NETWORK', 'ACCOUNT')),
    status TEXT CHECK(status IN ('PENDING', 'IN-PROGRESS', 'RESOLVED')) DEFAULT 'PENDING',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    user_id INTEGER,
    technician_id INTEGER,
    resolution_notes TEXT,
    sla_deadline DATETIME,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(technician_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    ticket_id INTEGER,
    message TEXT,
    is_read BOOLEAN DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(ticket_id) REFERENCES tickets(id)
  );
`);

// Seed Admin if not exists
const adminExists = db.prepare("SELECT * FROM users WHERE email = ?").get("admin@helpdesk.com");
if (!adminExists) {
  const hashedPassword = bcrypt.hashSync("admin123", 10);
  db.prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)").run("Admin User", "admin@helpdesk.com", hashedPassword, "ADMIN");
}

// Seed Employee if not exists
const employeeExists = db.prepare("SELECT * FROM users WHERE email = ?").get("employee@company.com");
if (!employeeExists) {
  const hashedPassword = bcrypt.hashSync("emp123", 10);
  const result = db.prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)").run("John Employee", "employee@company.com", hashedPassword, "USER");
  const employeeId = result.lastInsertRowid;

  // Add demo ticket for network down
  const demoTitle = "Network Down in Block A";
  const demoDesc = "The entire department is unable to access the internet. Network down problem.";
  
  // We'll hardcode the analysis for the seed to avoid async issues during startup
  const priority = "CRITICAL";
  const category = "NETWORK";
  const deadline = new Date();
  deadline.setHours(deadline.getHours() + 4); // 4 hours for critical

  db.prepare(`
    INSERT INTO tickets (title, description, priority, category, sla_deadline, user_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(demoTitle, demoDesc, priority, category, deadline.toISOString(), employeeId);
}

const app = express();
app.use(express.json());

// --- Smart Logic Functions ---

async function analyzeTicket(description: string) {
  const text = description.toLowerCase();
  
  // Try Gemini first if API key exists
  if (process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== "MY_GEMINI_API_KEY") {
    try {
      const suggestion = await getSmartSuggestion(description);
      if (suggestion && suggestion.priority) {
        const deadline = new Date();
        const slaHours = { CRITICAL: 4, HIGH: 8, MEDIUM: 24, LOW: 48 }[suggestion.priority as keyof typeof slaHours] || 48;
        deadline.setHours(deadline.getHours() + slaHours);
        return { 
          priority: suggestion.priority, 
          category: suggestion.category || "SOFTWARE", 
          sla_deadline: deadline.toISOString() 
        };
      }
    } catch (err) {
      console.error("Smart analysis failed, falling back to keywords:", err);
    }
  }

  // Fallback: Keyword Logic
  let priority = "MEDIUM"; // Default to Medium as requested
  
  const criticalKeywords = ["server down", "security breach", "data loss", "entire department"];
  const highKeywords = ["not working", "broken", "deadline", "urgent", "cannot login"];

  if (criticalKeywords.some(key => text.includes(key))) {
    priority = "CRITICAL";
  } else if (highKeywords.some(key => text.includes(key))) {
    priority = "HIGH";
  } else if (text.includes("low priority") || text.includes("minor")) {
    priority = "LOW";
  }

  // Category Logic
  let category = "SOFTWARE";
  if (text.includes("laptop") || text.includes("keyboard") || text.includes("monitor") || text.includes("hardware") || text.includes("printer")) {
    category = "HARDWARE";
  } else if (text.includes("wifi") || text.includes("internet") || text.includes("network") || text.includes("vpn")) {
    category = "NETWORK";
  } else if (text.includes("password") || text.includes("login") || text.includes("account") || text.includes("access")) {
    category = "ACCOUNT";
  }

  // SLA Calculation (Hours)
  const slaHours = {
    CRITICAL: 4,
    HIGH: 8,
    MEDIUM: 24,
    LOW: 48
  }[priority as keyof typeof slaHours];

  const deadline = new Date();
  deadline.setHours(deadline.getHours() + slaHours);

  return { priority, category, sla_deadline: deadline.toISOString() };
}

// --- Middleware ---

const authenticate = (req: AuthRequest, res: Response, next: NextFunction) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: "Unauthorized" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (err) {
    console.error("Auth error:", err);
    res.status(401).json({ error: "Invalid token" });
  }
};

const authorize = (roles: string[]) => (req: AuthRequest, res: Response, next: NextFunction) => {
  if (!roles.includes(req.user.role)) return res.status(403).json({ error: "Forbidden" });
  next();
};

// --- API Routes ---

app.post("/api/auth/register", (req: Request, res: Response) => {
  const { name, email, password, role } = req.body;
  try {
    const hashedPassword = bcrypt.hashSync(password, 10);
    const result = db.prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)").run(name, email, hashedPassword, role || "USER");
    res.json({ id: result.lastInsertRowid });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: "Email already exists" });
  }
});

app.post("/api/auth/login", (req: Request, res: Response) => {
  const { email, password } = req.body;
  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email) as { id: number; role: string; name: string; password: string } | undefined;
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const token = jwt.sign({ id: user.id, role: user.role, name: user.name }, JWT_SECRET);
  res.json({ token, user: { id: user.id, name: user.name, role: user.role } });
});

// Ticket Routes
app.post("/api/tickets", authenticate, async (req: AuthRequest, res: Response) => {
  const { title, description } = req.body;
  const { priority, category, sla_deadline } = await analyzeTicket(description);
  
  const result = db.prepare(`
    INSERT INTO tickets (title, description, priority, category, sla_deadline, user_id)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(title, description, priority, category, sla_deadline, req.user.id);
  
  res.json({ id: result.lastInsertRowid, priority, category });
});

app.get("/api/tickets", authenticate, (req: AuthRequest, res: Response) => {
  let tickets;
  if (req.user.role === "ADMIN") {
    tickets = db.prepare("SELECT t.*, u.name as user_name FROM tickets t JOIN users u ON t.user_id = u.id ORDER BY t.created_at DESC").all();
  } else if (req.user.role === "TECHNICIAN") {
    tickets = db.prepare("SELECT t.*, u.name as user_name FROM tickets t JOIN users u ON t.user_id = u.id WHERE t.technician_id = ? OR t.technician_id IS NULL ORDER BY t.created_at DESC").all(req.user.id);
  } else {
    tickets = db.prepare("SELECT * FROM tickets WHERE user_id = ? ORDER BY created_at DESC").all(req.user.id);
  }
  res.json(tickets);
});

app.patch("/api/tickets/:id", authenticate, (req: AuthRequest, res: Response) => {
  const { status, resolution_notes, technician_id } = req.body;
  const ticketId = req.params.id;

  if (req.user.role === "USER") return res.status(403).json({ error: "Users cannot update tickets directly" });

  db.prepare(`
    UPDATE tickets 
    SET status = COALESCE(?, status), 
        resolution_notes = COALESCE(?, resolution_notes),
        technician_id = COALESCE(?, technician_id),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(status, resolution_notes, technician_id, ticketId);

  // Create notification if resolved
  if (status === 'RESOLVED') {
    const ticket = db.prepare("SELECT user_id, title FROM tickets WHERE id = ?").get(ticketId) as { user_id: number; title: string };
    if (ticket) {
      db.prepare("INSERT INTO notifications (user_id, ticket_id, message) VALUES (?, ?, ?)").run(
        ticket.user_id,
        ticketId,
        `Your ticket "${ticket.title}" has been resolved.`
      );
    }
  }

  res.json({ success: true });
});

// Notifications
app.get("/api/notifications", authenticate, (req: AuthRequest, res: Response) => {
  const notifications = db.prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20").all(req.user?.id);
  res.json(notifications);
});

app.patch("/api/notifications/:id/read", authenticate, (req: AuthRequest, res: Response) => {
  db.prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?").run(req.params.id, req.user?.id);
  res.json({ success: true });
});

// Analytics
app.get("/api/analytics", authenticate, authorize(["ADMIN"]), (_req: AuthRequest, res: Response) => {
  const stats = {
    total: db.prepare("SELECT COUNT(*) as count FROM tickets").get().count,
    resolved: db.prepare("SELECT COUNT(*) as count FROM tickets WHERE status = 'RESOLVED'").get().count,
    pending: db.prepare("SELECT COUNT(*) as count FROM tickets WHERE status = 'PENDING'").get().count,
    byCategory: db.prepare("SELECT category, COUNT(*) as count FROM tickets GROUP BY category").all(),
    byPriority: db.prepare("SELECT priority, COUNT(*) as count FROM tickets GROUP BY priority").all()
  };
  res.json(stats);
});

// --- Vite Integration ---

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
