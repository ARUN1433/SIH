import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  LayoutDashboard, 
  Ticket as TicketIcon, 
  LogOut, 
  Plus, 
  Clock, 
  AlertCircle,
  CheckCircle2,
  Search,
  ShieldCheck,
  Cpu,
  UserCircle,
  X,
  ExternalLink,
  Bell,
  BellDot
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from 'recharts';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { User, Ticket, Analytics, Role, Notification } from './types';

// Utility for Tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

const Badge = ({ children, variant }: { children: React.ReactNode, variant: string }) => {
  const variants: Record<string, string> = {
    CRITICAL: "bg-red-100 text-red-700 border-red-200",
    HIGH: "bg-orange-100 text-orange-700 border-orange-200",
    MEDIUM: "bg-blue-100 text-blue-700 border-blue-200",
    LOW: "bg-green-100 text-green-700 border-green-200",
    PENDING: "bg-gray-100 text-gray-700 border-gray-200",
    "IN-PROGRESS": "bg-yellow-100 text-yellow-700 border-yellow-200",
    RESOLVED: "bg-emerald-100 text-emerald-700 border-emerald-200",
    HARDWARE: "bg-purple-100 text-purple-700 border-purple-200",
    SOFTWARE: "bg-indigo-100 text-indigo-700 border-indigo-200",
    NETWORK: "bg-cyan-100 text-cyan-700 border-cyan-200",
    ACCOUNT: "bg-pink-100 text-pink-700 border-pink-200",
  };
  return (
    <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold border uppercase tracking-wider", variants[variant] || "bg-gray-100")}>
      {children}
    </span>
  );
};

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [view, setView] = useState<'dashboard' | 'tickets' | 'new-ticket' | 'login' | 'register'>('login');
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  // Auth States
  const [authForm, setAuthForm] = useState({ email: '', password: '', name: '', role: 'USER' as Role });

  useEffect(() => {
    if (token) {
      const savedUser = localStorage.getItem('user');
      if (savedUser) {
        const parsed = JSON.parse(savedUser);
        setUser(parsed);
        setView(parsed.role === 'ADMIN' ? 'dashboard' : 'tickets');
      }
    }
  }, [token]);

  const fetchTickets = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/tickets', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setTickets(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchAnalytics = async () => {
    if (!token || user?.role !== 'ADMIN') return;
    try {
      const res = await fetch('/api/analytics', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setAnalytics(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchNotifications = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/notifications', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setNotifications(data);
    } catch (err) {
      console.error(err);
    }
  };

  const markNotificationAsRead = async (id: number) => {
    try {
      await fetch(`/api/notifications/${id}/read`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` }
      });
      fetchNotifications();
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (token) {
      fetchTickets();
      fetchNotifications();
      if (user?.role === 'ADMIN') fetchAnalytics();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, user]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: authForm.email, password: authForm.password })
      });
      const data = await res.json();
      if (data.token) {
        localStorage.setItem('token', data.token);
        localStorage.setItem('user', JSON.stringify(data.user));
        setToken(data.token);
        setUser(data.user);
      } else {
        alert(data.error);
      }
    } catch (err) {
      console.error(err);
      alert("Login failed");
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setToken(null);
    setUser(null);
    setView('login');
  };

  const TicketCard = ({ ticket }: { ticket: Ticket }) => {
    const isOverdue = new Date(ticket.sla_deadline) < new Date() && ticket.status !== 'RESOLVED';
    
    return (
      <motion.div 
        layout
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-slate-200 rounded-xl p-4 hover:shadow-md transition-all group flex flex-col"
      >
        <div className="flex justify-between items-start mb-3">
          <div className="flex gap-2 items-center">
            <Badge variant={ticket.priority}>{ticket.priority}</Badge>
            <Badge variant={ticket.status}>{ticket.status}</Badge>
          </div>
          <span className="text-[10px] font-mono text-slate-400">#{ticket.id}</span>
        </div>
        
        <h3 className="font-semibold text-slate-800 mb-1 line-clamp-1">{ticket.title}</h3>
        <p className="text-xs text-slate-500 line-clamp-2 mb-4 leading-relaxed flex-grow">{ticket.description}</p>
        
        <div className="flex items-center justify-between pt-4 border-t border-slate-50 mb-3">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center">
              <UserCircle className="w-4 h-4 text-slate-400" />
            </div>
            <span className="text-[11px] font-medium text-slate-600">{ticket.user_name || 'You'}</span>
          </div>
          
          <div className={cn(
            "flex items-center gap-1.5 text-[10px] font-bold px-2 py-1 rounded-md",
            isOverdue ? "text-red-600 bg-red-50" : "text-slate-500 bg-slate-50"
          )}>
            <Clock className="w-3 h-3" />
            {isOverdue ? 'OVERDUE' : new Date(ticket.sla_deadline).toLocaleDateString()}
          </div>
        </div>

        <button 
          onClick={() => setSelectedTicket(ticket)}
          className="w-full py-2 rounded-lg bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 text-[11px] font-bold transition-all flex items-center justify-center gap-2 border border-transparent hover:border-indigo-100"
        >
          <ExternalLink className="w-3 h-3" />
          View Details
        </button>
      </motion.div>
    );
  };

  const TicketModal = ({ ticket, onClose }: { ticket: Ticket, onClose: () => void }) => {
    const [resolutionNotes, setResolutionNotes] = useState('');
    const [isResolving, setIsResolving] = useState(false);

    const handleResolve = async (e: React.FormEvent) => {
      e.preventDefault();
      if (!resolutionNotes.trim()) return;
      
      setIsResolving(true);
      try {
        await axios.patch(`/api/tickets/${ticket.id}`, {
          status: 'RESOLVED',
          resolution_notes: resolutionNotes
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });
        fetchTickets();
        if (user?.role === 'ADMIN') fetchAnalytics();
        onClose();
      } catch (err) {
        console.error(err);
        alert("Failed to resolve ticket");
      } finally {
        setIsResolving(false);
      }
    };

    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div 
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
          onClick={e => e.stopPropagation()}
        >
          <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <div>
              <div className="flex gap-2 items-center mb-2">
                <Badge variant={ticket.priority}>{ticket.priority}</Badge>
                <Badge variant={ticket.category}>{ticket.category}</Badge>
                <Badge variant={ticket.status}>{ticket.status}</Badge>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">{ticket.title}</h2>
            </div>
            <button 
              onClick={onClose}
              className="w-10 h-10 rounded-full hover:bg-white hover:shadow-md flex items-center justify-center text-slate-400 hover:text-slate-600 transition-all"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="p-8 overflow-y-auto space-y-8">
            <section>
              <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Description</h4>
              <div className="bg-slate-50 p-6 rounded-2xl text-slate-700 text-sm leading-relaxed border border-slate-100">
                {ticket.description}
              </div>
            </section>

            <div className="grid grid-cols-2 gap-8">
              <section>
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Ticket Info</h4>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Created At</span>
                    <span className="font-semibold text-slate-700">{new Date(ticket.created_at).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">SLA Deadline</span>
                    <span className="font-semibold text-slate-700">{new Date(ticket.sla_deadline).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-400">Raised By</span>
                    <span className="font-semibold text-slate-700">{ticket.user_name || 'You'}</span>
                  </div>
                </div>
              </section>

              <section>
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Resolution Details</h4>
                {ticket.status === 'RESOLVED' ? (
                  <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100">
                    <p className="text-xs text-emerald-800 leading-relaxed italic">
                      {ticket.resolution_notes || "No resolution notes provided."}
                    </p>
                  </div>
                ) : (
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-center justify-center h-full min-h-[60px]">
                    <p className="text-xs text-slate-400 italic">Resolution pending...</p>
                  </div>
                )}
              </section>
            </div>

            {/* Admin/Technician Resolution Form */}
            {(user?.role === 'ADMIN' || user?.role === 'TECHNICIAN') && ticket.status !== 'RESOLVED' && (
              <section className="pt-6 border-t border-slate-100">
                <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">Resolve Ticket</h4>
                <form onSubmit={handleResolve} className="space-y-4">
                  <div>
                    <textarea 
                      required
                      placeholder="Enter resolution details..."
                      className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none resize-none text-sm"
                      rows={3}
                      value={resolutionNotes}
                      onChange={(e) => setResolutionNotes(e.target.value)}
                    />
                  </div>
                  <button 
                    disabled={isResolving}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-emerald-100 transition-all active:scale-[0.98] disabled:opacity-50 text-sm flex items-center justify-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    {isResolving ? 'Updating...' : 'Mark as Resolved'}
                  </button>
                </form>
              </section>
            )}
          </div>

          <div className="p-8 bg-slate-50/50 border-t border-slate-100 flex justify-end">
            <button 
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl bg-white border border-slate-200 text-slate-600 font-bold text-sm hover:bg-slate-50 transition-all"
            >
              Close
            </button>
          </div>
        </motion.div>
      </motion.div>
    );
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-6 font-sans">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-indigo-600 text-white mb-4 shadow-lg shadow-indigo-200">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 tracking-tight">Smart Helpdesk</h1>
            <p className="text-slate-500 mt-2">Enterprise IT Support Solution</p>
          </div>

          <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 p-8">
            <form onSubmit={handleLogin} className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Email Address</label>
                <input 
                  type="email" 
                  required
                  className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none text-slate-800"
                  placeholder="name@company.com"
                  value={authForm.email}
                  onChange={e => setAuthForm({...authForm, email: e.target.value})}
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Password</label>
                <input 
                  type="password" 
                  required
                  className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none text-slate-800"
                  placeholder="••••••••"
                  value={authForm.password}
                  onChange={e => setAuthForm({...authForm, password: e.target.value})}
                />
              </div>
              <button 
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 transition-all active:scale-[0.98] disabled:opacity-50"
              >
                {loading ? 'Authenticating...' : 'Sign In'}
              </button>
            </form>
            
            <div className="mt-8 pt-6 border-t border-slate-50 text-center space-y-2">
              <p className="text-[11px] text-slate-400 uppercase font-bold tracking-wider">Demo Credentials</p>
              <div className="flex flex-col gap-1">
                <p className="text-xs text-slate-500">
                  Admin: <span className="font-mono text-indigo-600 font-bold">admin@helpdesk.com / admin123</span>
                </p>
                <p className="text-xs text-slate-500">
                  Employee: <span className="font-mono text-indigo-600 font-bold">employee@company.com / emp123</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex font-sans text-slate-900">
      {/* Sidebar */}
      <aside className="w-72 bg-white border-r border-slate-200 flex flex-col sticky top-0 h-screen">
        <div className="p-8">
          <div className="flex items-center gap-3 mb-10">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-100">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-bold text-slate-900 leading-tight">Helpdesk</h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Enterprise v2.0</p>
            </div>
          </div>

          <nav className="space-y-1.5">
            {user?.role === 'ADMIN' && (
              <button 
                onClick={() => setView('dashboard')}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all",
                  view === 'dashboard' ? "bg-indigo-50 text-indigo-600" : "text-slate-500 hover:bg-slate-50"
                )}
              >
                <LayoutDashboard className="w-5 h-5" />
                Dashboard
              </button>
            )}
            <button 
              onClick={() => setView('tickets')}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all",
                view === 'tickets' ? "bg-indigo-50 text-indigo-600" : "text-slate-500 hover:bg-slate-50"
              )}
            >
              <TicketIcon className="w-5 h-5" />
              All Tickets
            </button>
            {user?.role === 'USER' && (
              <button 
                onClick={() => setView('new-ticket')}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all",
                  view === 'new-ticket' ? "bg-indigo-50 text-indigo-600" : "text-slate-500 hover:bg-slate-50"
                )}
              >
                <Plus className="w-5 h-5" />
                Raise Ticket
              </button>
            )}
          </nav>
        </div>

        <div className="mt-auto p-8 border-t border-slate-50">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center">
              <UserCircle className="w-6 h-6 text-slate-400" />
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-bold text-slate-900 truncate">{user?.name}</p>
              <p className="text-[10px] text-indigo-600 font-bold uppercase tracking-wider">{user?.role}</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold text-red-500 hover:bg-red-50 transition-all"
          >
            <LogOut className="w-5 h-5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-10 overflow-auto">
        <header className="flex justify-between items-center mb-10">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 tracking-tight capitalize">{view.replace('-', ' ')}</h1>
            <p className="text-slate-500 mt-1">Manage your IT support lifecycle efficiently.</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search tickets..."
                className="pl-11 pr-4 py-2.5 rounded-xl bg-white border border-slate-200 text-sm focus:ring-4 focus:ring-indigo-500/5 outline-none w-64"
              />
            </div>
            
            {/* Notifications */}
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-indigo-600 transition-all relative"
              >
                {notifications.some(n => !n.is_read) ? (
                  <BellDot className="w-5 h-5 text-indigo-600" />
                ) : (
                  <Bell className="w-5 h-5" />
                )}
              </button>

              <AnimatePresence>
                {showNotifications && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-slate-100 z-50 overflow-hidden"
                  >
                    <div className="p-4 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                      <h3 className="font-bold text-sm text-slate-900">Notifications</h3>
                      <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                        {notifications.filter(n => !n.is_read).length} New
                      </span>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length > 0 ? (
                        notifications.map((n) => (
                          <div 
                            key={n.id} 
                            onClick={() => markNotificationAsRead(n.id)}
                            className={cn(
                              "p-4 border-b border-slate-50 cursor-pointer transition-all hover:bg-slate-50",
                              !n.is_read && "bg-indigo-50/30"
                            )}
                          >
                            <p className="text-xs text-slate-800 leading-relaxed mb-1">{n.message}</p>
                            <p className="text-[10px] text-slate-400">{new Date(n.created_at).toLocaleString()}</p>
                          </div>
                        ))
                      ) : (
                        <div className="p-8 text-center">
                          <p className="text-xs text-slate-400">No notifications yet.</p>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {selectedTicket && (
            <TicketModal 
              ticket={selectedTicket} 
              onClose={() => setSelectedTicket(null)} 
            />
          )}
          {view === 'dashboard' && analytics && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-4 gap-6">
                {[
                  { label: 'Total Tickets', value: analytics.total, icon: TicketIcon, color: 'text-indigo-600', bg: 'bg-indigo-50' },
                  { label: 'Resolved', value: analytics.resolved, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                  { label: 'Pending', value: analytics.pending, icon: Clock, color: 'text-orange-600', bg: 'bg-orange-50' },
                  { label: 'Avg Time', value: '4.2h', icon: AlertCircle, color: 'text-blue-600', bg: 'bg-blue-50' },
                ].map((stat, i) => (
                  <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                    <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center mb-4", stat.bg)}>
                      <stat.icon className={cn("w-6 h-6", stat.color)} />
                    </div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                    <p className="text-3xl font-bold text-slate-900">{stat.value}</p>
                  </div>
                ))}
              </div>

              {/* Charts */}
              <div className="grid grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                  <h3 className="text-lg font-bold text-slate-800 mb-6">Tickets by Category</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analytics.byCategory}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                        <XAxis dataKey="category" axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 600, fill: '#94A3B8' }} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fontWeight: 600, fill: '#94A3B8' }} />
                        <Tooltip cursor={{ fill: '#F8FAFC' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }} />
                        <Bar dataKey="count" fill="#4F46E5" radius={[4, 4, 0, 0]} barSize={40} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
                  <h3 className="text-lg font-bold text-slate-800 mb-6">Priority Distribution</h3>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={analytics.byPriority}
                          dataKey="count"
                          nameKey="priority"
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                        >
                          {analytics.byPriority.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={['#EF4444', '#F59E0B', '#3B82F6', '#10B981'][index % 4]} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'tickets' && (
            <motion.div 
              key="tickets"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-3 gap-6"
            >
              {tickets.length > 0 ? (
                tickets.map(ticket => <TicketCard key={ticket.id} ticket={ticket} />)
              ) : (
                <div className="col-span-3 py-20 text-center">
                  <div className="w-20 h-20 rounded-full bg-slate-50 flex items-center justify-center mx-auto mb-4">
                    <TicketIcon className="w-10 h-10 text-slate-200" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-800">No tickets found</h3>
                  <p className="text-slate-400">Everything looks clear for now.</p>
                </div>
              )}
            </motion.div>
          )}

          {view === 'new-ticket' && (
            <motion.div 
              key="new-ticket"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-2xl mx-auto bg-white p-10 rounded-3xl border border-slate-200 shadow-xl shadow-slate-200/50"
            >
              <form onSubmit={async (e) => {
                e.preventDefault();
                const form = e.target as HTMLFormElement;
                const formData = new FormData(form);
                try {
                  const response = await axios.post('/api/tickets', {
                    title: formData.get('title'),
                    description: formData.get('description')
                  }, {
                    headers: { Authorization: `Bearer ${token}` }
                  });
                  
                  if (response.data.priority) {
                    alert(`Success! Your ticket has been created.\n\nAuto-Assigned Priority: ${response.data.priority}\nCategory: ${response.data.category}`);
                  }
                  
                  fetchTickets();
                  setView('tickets');
                } catch (err) {
                  console.error(err);
                  alert("Failed to create ticket");
                }
              }} className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Ticket Title</label>
                  <input 
                    name="title"
                    required
                    placeholder="e.g., VPN connection failing"
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Description</label>
                  <textarea 
                    name="description"
                    required
                    rows={5}
                    placeholder="Describe the issue in detail. Our smart engine will auto-prioritize it."
                    className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all outline-none resize-none"
                  />
                </div>
                
                <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
                  <div className="flex gap-3 items-start">
                    <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shrink-0">
                      <Cpu className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-indigo-900 mb-1">Smart Engine Active</h4>
                      <p className="text-xs text-indigo-700 leading-relaxed">
                        We use keyword analysis to automatically assign priority and category to your ticket for faster resolution.
                      </p>
                    </div>
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-200 transition-all active:scale-[0.98]"
                >
                  Submit Ticket
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
