import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function getSmartSuggestion(description: string) {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this IT support ticket description and provide a JSON response with:
      1. priority (CRITICAL, HIGH, MEDIUM, LOW)
      2. category (HARDWARE, SOFTWARE, NETWORK, ACCOUNT)
      3. a short summary (max 10 words)
      
      Description: "${description}"`,
      config: {
        responseMimeType: "application/json"
      }
    });
    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("Gemini Error:", error);
    return null;
  }
}
