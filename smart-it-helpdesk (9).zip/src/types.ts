export type Role = 'USER' | 'TECHNICIAN' | 'ADMIN';
export type Priority = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
export type Category = 'HARDWARE' | 'SOFTWARE' | 'NETWORK' | 'ACCOUNT';
export type Status = 'PENDING' | 'IN-PROGRESS' | 'RESOLVED';

export interface User {
  id: number;
  name: string;
  email: string;
  role: Role;
}

export interface Ticket {
  id: number;
  title: string;
  description: string;
  priority: Priority;
  category: Category;
  status: Status;
  created_at: string;
  updated_at: string;
  user_id: number;
  user_name?: string;
  technician_id?: number;
  resolution_notes?: string;
  sla_deadline: string;
}

export interface Analytics {
  total: number;
  resolved: number;
  pending: number;
  byCategory: { category: Category; count: number }[];
  byPriority: { priority: Priority; count: number }[];
}

export interface Notification {
  id: number;
  user_id: number;
  ticket_id: number;
  message: string;
  is_read: boolean;
  created_at: string;
}
